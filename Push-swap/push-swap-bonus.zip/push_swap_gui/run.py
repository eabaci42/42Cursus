#!/usr/bin/env python3

from push_swap_gui.__main__ import main


if __name__ == '__main__':
	main()
